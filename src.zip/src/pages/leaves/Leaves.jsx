import React from 'react';

export default function Leaves() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Leaves</h1>
      <p className="text-gray-500 mt-2">Module Under Development</p>
    </div>
  );
}
